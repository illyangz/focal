const { app, BrowserWindow, ipcMain, desktopCapturer, screen, globalShortcut, systemPreferences, shell, session } = require("electron");
const path = require("path");

// Global click detection (optional — needs Accessibility permission on macOS).
// If unavailable, the renderer falls back to dwell-based zoom detection.
let uIOhook = null;
try {
  ({ uIOhook } = require("uiohook-napi"));
} catch (e) {
  console.log("[studio] uiohook-napi not available — using dwell-based auto-zoom fallback.");
}

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: "#0c0c0f",
    title: "Studio",
    icon: path.join(__dirname, "build", "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile("renderer.html");
}

let selectedSourceId = null;
ipcMain.on("select-source", (e, id) => { selectedSourceId = id; });

app.whenReady().then(() => {
  if (process.platform === "darwin") {
    try { app.dock.setIcon(path.join(__dirname, "build", "icon.png")); } catch {}
  }
  // Serve the source the renderer picked when it calls getDisplayMedia
  // (lets us use the modern API, which supports hiding the system cursor).
  session.defaultSession.setDisplayMediaRequestHandler(async (request, callback) => {
    try {
      const sources = await desktopCapturer.getSources({ types: ["screen", "window"] });
      const src = sources.find((s) => s.id === selectedSourceId) || sources[0];
      callback({ video: src, audio: false });
    } catch (e) {
      callback({});
    }
  });
  createWindow();
  // Stop-recording hotkey (works while other apps are focused)
  globalShortcut.register("CommandOrControl+Shift+S", () => {
    if (win) {
      win.webContents.send("hotkey-stop");
    }
  });
});

app.on("window-all-closed", () => app.quit());
app.on("will-quit", () => {
  globalShortcut.unregisterAll();
  if (uIOhook && hookStarted) {
    try { uIOhook.stop(); } catch {}
  }
});

/* ---------- Permissions ---------- */
ipcMain.handle("screen-perm", () => {
  // 'granted' | 'denied' | 'restricted' | 'not-determined' (always 'granted' on Win/Linux)
  if (process.platform !== "darwin") return "granted";
  return systemPreferences.getMediaAccessStatus("screen");
});
ipcMain.on("open-screen-settings", () => {
  if (process.platform === "darwin") {
    shell.openExternal("x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture");
  }
});

/* ---------- Screen sources ---------- */
ipcMain.handle("get-sources", async () => {
  const sources = await desktopCapturer.getSources({
    types: ["screen", "window"],
    thumbnailSize: { width: 420, height: 260 },
  });
  const displays = screen.getAllDisplays();
  return sources
    .filter((s) => s.name !== "Studio") // don't offer our own window
    .map((s) => {
      const isScreen = s.id.startsWith("screen");
      const d = isScreen
        ? displays.find((d) => String(d.id) === String(s.display_id)) || screen.getPrimaryDisplay()
        : null;
      return {
        id: s.id,
        name: s.name,
        kind: isScreen ? "screen" : "window",
        thumbnail: s.thumbnail.toDataURL(),
        bounds: d ? d.bounds : null, // DIP coordinates — same space as getCursorScreenPoint()
        scaleFactor: d ? d.scaleFactor : 1,
      };
    });
});

/* ---------- Cursor & click tracking ---------- */
let events = [];
let pollTimer = null;
let lastPos = { x: 0, y: 0 };
let tracking = false;
let hookStarted = false;

function onMouseDown() {
  if (!tracking) return;
  // Use the last polled cursor position (DIP space) rather than hook coords,
  // which may be in physical pixels on some platforms.
  events.push({ t: Date.now(), x: lastPos.x, y: lastPos.y, c: 1 });
}

ipcMain.handle("track-start", () => {
  events = [];
  tracking = true;
  lastPos = screen.getCursorScreenPoint();
  pollTimer = setInterval(() => {
    const p = screen.getCursorScreenPoint();
    lastPos = p;
    events.push({ t: Date.now(), x: p.x, y: p.y, c: 0 });
  }, 16);

  let clicksAvailable = false;
  if (uIOhook) {
    try {
      if (!hookStarted) {
        uIOhook.on("mousedown", onMouseDown);
        uIOhook.start();
        hookStarted = true;
      }
      clicksAvailable = true;
    } catch (e) {
      console.log("[studio] global click hook failed:", e.message);
    }
  }
  return { clicksAvailable };
});

ipcMain.handle("track-stop", () => {
  tracking = false;
  clearInterval(pollTimer);
  pollTimer = null;
  return events;
});

/* ---------- Shareable link upload (0x0.st, anonymous, ~30-day retention) ---------- */
ipcMain.handle("share-upload", async (e, buf, name) => {
  const fd = new FormData();
  fd.append("file", new Blob([Buffer.from(buf)]), name);
  const res = await fetch("https://0x0.st", {
    method: "POST",
    body: fd,
    headers: { "User-Agent": "StudioRecorder/1.0" },
  });
  const text = (await res.text()).trim();
  if (!res.ok || !text.startsWith("http")) {
    throw new Error(text.slice(0, 120) || "Upload failed (HTTP " + res.status + ")");
  }
  return text;
});

/* ---------- Window helpers ---------- */
ipcMain.on("win-minimize", () => win && win.minimize());
ipcMain.on("win-restore", () => {
  if (!win) return;
  win.restore();
  win.show();
  win.focus();
});
